# 🌿 Dashboard Tekno-Ekonomi Bio-CNG KPBS Pangalengan

Dashboard interaktif Streamlit + Plotly untuk model techno-economic Bio-CNG skala 9 Nm³/jam, 340 ekor sapi, 15 tahun.

**Fitur:**
- KPI M4 vs Konvensional (NPV, LCOE, Payback)
- Simulasi real-time: Discount Rate, Harga Jual, CAPEX, OPEX, Feedstock multiplier
- Grafik Cumulative Cashflow 0-15 tahun
- Donut CAPEX & OPEX
- Tornado Sensitivitas
- Break-even Finder & What-If NPV vs Harga
- Export PDF Tesis & CSV Cashflow

## Cara Deploy ke Streamlit Cloud
1. Buat repo GitHub baru, upload semua file di folder ini
2. Pastikan file Excel `Model-Techno-Economic-Bio-CNG-KPBS-Pangalengan.xlsx` ada di root repo
3. Buka https://share.streamlit.io/ -> New App -> pilih repo -> Main file: `app.py` -> Deploy
4. Selesai! URL akan jadi `https://<username>-bio-cng-kpbs.streamlit.app`

## Local run
```bash
pip install -r requirements.txt
streamlit run app.py
```

© 2026 Suryaman Aan - KPBS Pangalengan
