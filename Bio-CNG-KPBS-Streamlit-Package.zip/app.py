"""
Dashboard Tekno-Ekonomi Bio-CNG KPBS Pangalengan v2
Tambahan: Optimasi Break-even + Export PDF Report + What-if Scenario Presets
Cara jalan:
pip install streamlit plotly pandas openpyxl reportlab kaleido
streamlit run app_v2.py
"""

import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
from pathlib import Path
import io
from datetime import datetime

# PDF generation (reportlab)
try:
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.units import mm
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.lib import colors
    HAS_REPORTLAB = True
except:
    HAS_REPORTLAB = False

st.set_page_config(
    page_title="Bio-CNG KPBS Pangalengan | Dashboard v2",
    page_icon="🌿",
    layout="wide",
    initial_sidebar_state="expanded"
)

st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap');
html, body, [class*="css"] { font-family: 'Inter', sans-serif; }
.metric-card {
    background: white;
    border-radius: 16px;
    padding: 20px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.06);
    border: 1px solid #EEF2F7;
    text-align: left;
    height: 100%;
}
.metric-title { font-size: 11px; color: #6B7280; font-weight: 700; letter-spacing: 0.6px; text-transform: uppercase; }
.metric-value { font-size: 20px; font-weight: 800; margin-top:6px; color:#111827; }
.metric-delta { font-size: 12px; margin-top:4px; color:#4B5563; }
.insight-box { background:#f0fdf4; border:1px solid #bbf7d0; border-radius:12px; padding:14px; }
.presets { background:#f8fafc; border-radius:12px; padding:10px; border:1px solid #e2e8f0; }
</style>
""", unsafe_allow_html=True)

EXCEL_PATH = Path("Model-Techno-Economic-Bio-CNG-KPBS-Pangalengan.xlsx")
if not EXCEL_PATH.exists():
    EXCEL_PATH = Path("/mnt/data/Model-Techno-Economic-Bio-CNG-KPBS-Pangalengan.xlsx")

@st.cache_data
def load_excel_safely(path):
    data = {}
    def find_header_row(df_raw, keywords):
        for idx, row in df_raw.iterrows():
            row_str = " ".join([str(v).lower() for v in row.values if pd.notna(v)])
            for kw in keywords:
                if kw.lower() in row_str:
                    return idx
        return 0
    try:
        raw = pd.read_excel(path, sheet_name="Dashboard", header=None)
        h_idx = find_header_row(raw, ["indikator"])
        data['dashboard'] = pd.read_excel(path, sheet_name="Dashboard", header=h_idx)
    except: data['dashboard']=pd.DataFrame()
    try:
        raw = pd.read_excel(path, sheet_name="Asumsi_Umum", header=None)
        h_idx = find_header_row(raw, ["parameter"])
        df = pd.read_excel(path, sheet_name="Asumsi_Umum", header=h_idx)
        df = df.dropna(subset=[df.columns[0]]).reset_index(drop=True)
        data['asumsi']=df
    except: data['asumsi']=pd.DataFrame()
    try:
        raw = pd.read_excel(path, sheet_name="CAPEX", header=None)
        h_idx = find_header_row(raw, ["komponen"])
        df = pd.read_excel(path, sheet_name="CAPEX", header=h_idx)
        data['capex']=df.dropna(subset=[df.columns[0]])
    except: data['capex']=pd.DataFrame()
    try:
        df = pd.read_excel(path, sheet_name="OPEX_Produksi", header=None, skiprows=10)
        df.columns = ["col0","Komponen","Nilai","Satuan","Catatan","c5","c6"]
        data['opex']=df.dropna(subset=["Komponen"])
    except: data['opex']=pd.DataFrame()
    try:
        raw = pd.read_excel(path, sheet_name="Kelayakan", header=None)
        h_idx = find_header_row(raw, ["indikator kelayakan"])
        data['kelayakan']=pd.read_excel(path, sheet_name="Kelayakan", header=h_idx)
        h2_idx=None
        for i,r in raw.iterrows():
            if "komponen pv" in str(r[1]).lower():
                h2_idx=i; break
        if h2_idx is not None:
            data['kelayakan_pv']=pd.read_excel(path, sheet_name="Kelayakan", header=h2_idx)
    except: data['kelayakan']=pd.DataFrame()
    def parse_cashflow(sheet_name):
        try:
            raw = pd.read_excel(path, sheet_name=sheet_name, header=None)
            year_row_idx = find_header_row(raw, ["tahun ke-"])
            year_row = raw.iloc[year_row_idx]
            years = year_row[2:].astype(float).tolist()
            dict_data={}
            for idx in range(year_row_idx+1, len(raw)):
                r=raw.iloc[idx]
                key=str(r[1]).strip()
                if key=='' or key.lower()=='nan' or pd.isna(r[1]): continue
                values=r[2:2+len(years)].tolist()
                dict_data[key]=values
            df_cf=pd.DataFrame(dict_data, index=years).reset_index().rename(columns={'index':'Tahun'})
            return df_cf, dict_data, years
        except: return pd.DataFrame(), {}, []
    data['cf_m4_df'], data['cf_m4_dict'], data['years']=parse_cashflow("Cashflow_M4")
    data['cf_konv_df'], data['cf_konv_dict'], _=parse_cashflow("Cashflow_Konvensional")
    try:
        raw=pd.read_excel(path, sheet_name="Sensitivitas", header=None)
        m4_start=konv_start=None
        for i,r in raw.iterrows():
            if "skema m4" in str(r[1]).lower(): m4_start=i
            if "skema konvensional" in str(r[1]).lower(): konv_start=i
        if m4_start is not None: data['sens_m4']=pd.read_excel(path, sheet_name="Sensitivitas", header=m4_start+1, nrows=5)
        if konv_start is not None: data['sens_konv']=pd.read_excel(path, sheet_name="Sensitivitas", header=konv_start+1, nrows=5)
    except: data['sens_m4']=pd.DataFrame(); data['sens_konv']=pd.DataFrame()
    try:
        raw=pd.read_excel(path, sheet_name="Feedstock_M4_vs_Konvensional", header=None)
        h_idx=find_header_row(raw, ["parameter"])
        data['feedstock']=pd.read_excel(path, sheet_name="Feedstock_M4_vs_Konvensional", header=h_idx)
    except: data['feedstock']=pd.DataFrame()
    return data

data = load_excel_safely(EXCEL_PATH)

# helpers
def get_asumsi_val(keyword, default):
    try:
        df=data['asumsi']
        row=df[df.iloc[:,0].astype(str).str.contains(keyword, case=False, na=False)]
        if not row.empty: return float(row.iloc[0,1])
        return default
    except: return default

def recalc_npv(dict_cf, discount, capex_mult_f, price_mult, feed_mult, opex_mult=1.0):
    if not dict_cf: return None,None,None
    net_base=dict_cf.get('Arus Kas Bersih (Net Cash Flow)')
    total_pend=dict_cf.get('TOTAL PENDAPATAN')
    biaya_feed=dict_cf.get('Biaya Feedstock')
    opex_non=dict_cf.get('OPEX Non-Feedstock (eskalasi)')
    capex=dict_cf.get('Capital Expenditure (CAPEX)')
    years=data.get('years', list(range(0,16)))
    if net_base is None: return None,None,None
    adjusted=[]
    for i,t in enumerate(years):
        nb=net_base[i] if i < len(net_base) else 0
        tp=total_pend[i] if total_pend and i < len(total_pend) else 0
        bf=biaya_feed[i] if biaya_feed and i < len(biaya_feed) else 0
        on=opex_non[i] if opex_non and i < len(opex_non) else 0
        delta_rev=tp*(price_mult-1)
        delta_feed=bf*(feed_mult-1)
        delta_opex=on*(opex_mult-1)
        capex_adj=0
        if capex and i < len(capex) and capex[i]!=0:
            capex_adj=capex[i]*(capex_mult_f-1) if t==0 or t==8 else 0
            # tahun 0 special
            if t==0:
                adj = capex[i]*capex_mult_f
                # capex negative in sheet, so keep negative
                adjusted.append(adj)
                continue
        adj=nb + delta_rev - delta_feed - delta_opex - capex_adj
        adjusted.append(adj)
    discounted=[cf/((1+discount)**t) if t!=0 else cf for t,cf in zip(years, adjusted)]
    npv=sum(discounted)
    cum=np.cumsum(adjusted).tolist()
    return npv, adjusted, cum

# ---------- SIDEBAR ----------
st.sidebar.markdown("## ⚙️ Simulasi Skenario")
preset = st.sidebar.selectbox("🎯 Preset Skenario Cepat", ["Base Case (Excel)", "Optimistis - Harga Industri", "Pessimistis - CAPEX +20%", "Best Case - Carbon Credit + Efisiensi", "Custom (Manual Slider)"], index=0)

# default mapping preset -> multipliers
if preset == "Base Case (Excel)":
    d_rate, h_mult, f_mult, c_mult, o_mult = 0.10, 1.0, 1.0, 1.0, 1.0
elif preset == "Optimistis - Harga Industri":
    d_rate, h_mult, f_mult, c_mult, o_mult = 0.10, 1.44, 1.0, 1.0, 0.9  # 4500*1.44=6480
elif preset == "Pessimistis - CAPEX +20%":
    d_rate, h_mult, f_mult, c_mult, o_mult = 0.12, 1.0, 1.1, 1.2, 1.1
elif preset == "Best Case - Carbon Credit + Efisiensi":
    d_rate, h_mult, f_mult, c_mult, o_mult = 0.08, 1.6, 0.9, 0.9, 0.85
else:
    d_rate, h_mult, f_mult, c_mult, o_mult = 0.10, 1.0, 1.0, 1.0, 1.0

default_discount=get_asumsi_val("Discount Rate", d_rate)
default_eskalasi_opex=get_asumsi_val("Eskalasi Biaya OPEX", 0.035)

if preset == "Custom (Manual Slider)":
    discount_rate = st.sidebar.slider("Discount Rate / WACC (%)", 5.0, 20.0, float(default_discount*100), 0.5)/100
    harga_cng_mult = st.sidebar.slider("Harga Jual Bio-CNG Multiplier", 0.5, 2.5, 1.0, 0.05)
    feedstock_mult = st.sidebar.slider("Biaya Feedstock Multiplier", 0.5, 2.0, 1.0, 0.05)
    capex_mult = st.sidebar.slider("Total CAPEX Multiplier", 0.7, 1.5, 1.0, 0.05)
    opex_mult = st.sidebar.slider("OPEX Non-Feedstock Multiplier", 0.6, 1.5, 1.0, 0.05)
else:
    discount_rate = st.sidebar.slider("Discount Rate / WACC (%)", 5.0, 20.0, float(d_rate*100), 0.5)/100
    harga_cng_mult = st.sidebar.slider("Harga Jual Bio-CNG Multiplier", 0.5, 2.5, float(h_mult), 0.05)
    feedstock_mult = st.sidebar.slider("Biaya Feedstock Multiplier", 0.5, 2.0, float(f_mult), 0.05)
    capex_mult = st.sidebar.slider("Total CAPEX Multiplier", 0.7, 1.5, float(c_mult), 0.05)
    opex_mult = st.sidebar.slider("OPEX Non-Feedstock Multiplier", 0.6, 1.5, float(o_mult), 0.05)

st.sidebar.markdown("---")
st.sidebar.markdown(f"**Harga Jual Efektif:** Rp {4500*harga_cng_mult:,.0f} /Nm³ (Base Rp 4.500)")
st.sidebar.markdown(f"**CAPEX M4 Efektif:** Rp {8222000000*capex_mult/1e9:.2f} Miliar")
st.sidebar.info("💡 Tip: NPV masih negatif karena OPEX > Revenue. Coba preset Optimistis untuk lihat break-even.")

# recalc
years=data.get('years', list(range(0,16)))
npv_m4, cf_m4_adj, cum_m4 = recalc_npv(data.get('cf_m4_dict',{}), discount_rate, capex_mult, harga_cng_mult, feedstock_mult, opex_mult)
npv_konv, cf_konv_adj, cum_konv = recalc_npv(data.get('cf_konv_dict',{}), discount_rate, capex_mult, harga_cng_mult, feedstock_mult, opex_mult)

# ---------- BREAK-EVEN CALCULATION ----------
def find_breakeven_price():
    # cari multiplier harga agar NPV M4 = 0
    for mult in np.arange(1.0, 5.0, 0.05):
        npv_test,_ ,_ = recalc_npv(data.get('cf_m4_dict',{}), discount_rate, capex_mult, mult, feedstock_mult, opex_mult)
        if npv_test and npv_test>0:
            return mult, mult*4500, npv_test
    return None, None, None

be_mult, be_price, be_npv = find_breakeven_price()

# ---------- HEADER ----------
st.markdown("# 🌿 Dashboard Tekno-Ekonomi Bio-CNG KPBS Pangalengan v2")
st.markdown("**M4 vs Konvensional | 9 Nm³/jam | 340 Sapi | Optimasi & Export PDF**")

# KPI
col1,col2,col3,col4 = st.columns(4)
def fmt_rp(v):
    if v is None or pd.isna(v): return "N/A"
    if abs(v)>=1e12: return f"Rp {v/1e12:.2f} T"
    return f"Rp {v/1e9:.2f} M"

base_kel = data.get('kelayakan', pd.DataFrame())
base_npv_m4=base_npv_konv=base_lcoe_m4=base_lcoe_konv=None
try:
    if not base_kel.empty:
        npv_row=base_kel[base_kel.iloc[:,0].astype(str).str.contains("NPV", na=False)]
        if not npv_row.empty:
            base_npv_m4=float(npv_row.iloc[0,1]); base_npv_konv=float(npv_row.iloc[0,2])
        lcoe_row=base_kel[base_kel.iloc[:,0].astype(str).str.contains("LCOE", na=False)]
        if not lcoe_row.empty:
            base_lcoe_m4=float(lcoe_row.iloc[0,1]); base_lcoe_konv=float(lcoe_row.iloc[0,2])
except: pass

with col1:
    st.markdown(f"""<div class="metric-card"><div class="metric-title">NPV M4 Simulasi</div><div class="metric-value" style="color:{'#16a34a' if (npv_m4 or 0)>0 else '#dc2626'}">{fmt_rp(npv_m4)}</div><div class="metric-delta">Base: {fmt_rp(base_npv_m4)} | Selisih: {(npv_m4-base_npv_m4)/1e9:.1f} M</div></div>""", unsafe_allow_html=True)
with col2:
    st.markdown(f"""<div class="metric-card"><div class="metric-title">NPV Konv Simulasi</div><div class="metric-value" style="color:{'#16a34a' if (npv_konv or 0)>0 else '#dc2626'}">{fmt_rp(npv_konv)}</div><div class="metric-delta">Δ M4-KONV: {(npv_m4-npv_konv)/1e6:.1f} Juta</div></div>""", unsafe_allow_html=True)
with col3:
    st.markdown(f"""<div class="metric-card"><div class="metric-title">Break-Even Harga CNG</div><div class="metric-value">Rp {be_price:,.0f} /Nm³</div><div class="metric-delta">Multiplier {be_mult:.2f}x | Agar NPV>0 | Saat ini Rp {4500*harga_cng_mult:,.0f}</div></div>""", unsafe_allow_html=True)
with col4:
    def calc_payback(cum_list):
        for i in range(1,len(cum_list)):
            if cum_list[i]>=0:
                prev=cum_list[i-1]; curr=cum_list[i]
                if curr-prev!=0:
                    frac=-prev/(curr-prev)
                    return (i-1)+frac
                return i
        return None
    pb_m4=calc_payback(cum_m4) if cum_m4 else None
    st.markdown(f"""<div class="metric-card"><div class="metric-title">LCOE & Payback</div><div class="metric-value">LCOE Rp {base_lcoe_m4:,.0f}</div><div class="metric-delta">Payback M4: {f"{pb_m4:.1f} th" if pb_m4 else ">15 th (N/A)"} | Konv LCOE Rp {base_lcoe_konv:,.0f}</div></div>""", unsafe_allow_html=True)

# Optimization insight
if be_price:
    if harga_cng_mult*4500 >= be_price:
        st.success(f"✅ Skenario saat ini SUDAH LAYAK! Harga Rp {harga_cng_mult*4500:,.0f} >= Break-even Rp {be_price:,.0f} → NPV positif.")
    else:
        st.warning(f"⚠️ Belum layak. Butuh harga minimal **Rp {be_price:,.0f}/Nm³** ({be_mult:.2f}x base) agar NPV M4 = 0 pada discount {discount_rate*100:.1f}%. Skenario saat ini Rp {harga_cng_mult*4500:,.0f}.")

st.markdown("---")
c1,c2 = st.columns([2,1])
with c1:
    st.markdown("#### 💸 Cumulative Cashflow 0–15 Tahun (Simulasi)")
    fig=go.Figure()
    if cum_m4 and cum_konv:
        fig.add_trace(go.Scatter(x=years, y=cum_m4, mode='lines+markers', name='M4 Simulasi', line=dict(color='#16a34a', width=3)))
        fig.add_trace(go.Scatter(x=years, y=cum_konv, mode='lines+markers', name='Konv Simulasi', line=dict(color='#ef4444', width=2, dash='dot')))
        if data.get('cf_m4_dict',{}).get('Arus Kas Kumulatif'):
            fig.add_trace(go.Scatter(x=years, y=data['cf_m4_dict']['Arus Kas Kumulatif'], mode='lines', name='M4 Base Excel', line=dict(color='#86efac', width=1), opacity=0.5))
        fig.add_hline(y=0, line_dash="dash", line_color="gray")
        fig.update_layout(template="plotly_white", hovermode="x unified", yaxis_title="Rp", xaxis_title="Tahun", legend=dict(orientation="h", y=1.02, x=1), height=420)
        st.plotly_chart(fig, use_container_width=True)
with c2:
    st.markdown("#### 🏗️ CAPEX Breakdown")
    df_capex=data.get('capex', pd.DataFrame())
    if not df_capex.empty:
        try:
            biaya_col=df_capex.columns[1]; komp_col=df_capex.columns[0]
            df_plot=df_capex.iloc[:6].copy()
            df_plot=df_plot[[komp_col, biaya_col]].rename(columns={komp_col:"Komponen", biaya_col:"Biaya"})
            df_plot["Biaya"]=pd.to_numeric(df_plot["Biaya"], errors='coerce'); df_plot=df_plot.dropna()
            fig2=px.pie(df_plot, values="Biaya", names="Komponen", hole=0.55, color_discrete_sequence=px.colors.sequential.Greens_r)
            fig2.update_layout(height=380, margin=dict(l=10,r=10,t=10,b=10))
            st.plotly_chart(fig2, use_container_width=True)
        except Exception as e: st.write(e)
    st.markdown("#### ⚙️ OPEX Y1")
    df_opex=data.get('opex', pd.DataFrame())
    if not df_opex.empty:
        try:
            df_o=df_opex[df_opex["Komponen"].astype(str).str.contains("Tenaga|Pemeliharaan|Utilitas|Asuransi|Administrasi", na=False)]
            df_o["Nilai"]=pd.to_numeric(df_o["Nilai"], errors='coerce')
            fig3=px.pie(df_o, values="Nilai", names="Komponen", hole=0.55, color_discrete_sequence=px.colors.sequential.Oranges_r)
            fig3.update_layout(height=300, margin=dict(l=10,r=10,t=10,b=10))
            st.plotly_chart(fig3, use_container_width=True)
        except: pass

# Tornado + Feedstock
st.markdown("### 🌪️ Tornado Sensitivitas NPV M4")
col_t1,col_t2 = st.columns([1.4,1])
with col_t1:
    df_sens=data.get('sens_m4', pd.DataFrame())
    if not df_sens.empty:
        try:
            base_col=[c for c in df_sens.columns if "Base" in str(c)][0]
            minus20=[c for c in df_sens.columns if "-20" in str(c)][0]
            plus20=[c for c in df_sens.columns if "+20%" in str(c)][0]
            df_t=df_sens.copy()
            df_t["low"]=df_t[minus20]-df_t[base_col]
            df_t["high"]=df_t[plus20]-df_t[base_col]
            df_t["var"]=df_t.iloc[:,0]
            df_t["range"]=abs(df_t["high"]-df_t["low"])
            df_t=df_t.sort_values("range", ascending=True)
            fig_t=go.Figure()
            fig_t.add_trace(go.Bar(y=df_t["var"], x=df_t["low"], orientation='h', name='-20%', marker_color='#fca5a5'))
            fig_t.add_trace(go.Bar(y=df_t["var"], x=df_t["high"], orientation='h', name='+20%', marker_color='#4ade80'))
            fig_t.update_layout(barmode='relative', template="plotly_white", xaxis_title="Δ NPV (Rp)", height=400, margin=dict(l=10,r=10,t=10,b=10), legend=dict(orientation="h", y=1.05))
            st.plotly_chart(fig_t, use_container_width=True)
        except Exception as e: st.write(e)
with col_t2:
    st.markdown('<div class="insight-box">', unsafe_allow_html=True)
    st.markdown(f"""
    **Insight Simulasi Saat Ini ({preset}):**
    - NPV M4: **{fmt_rp(npv_m4)}** | NPV Konv: **{fmt_rp(npv_konv)}**
    - Break-even: **Rp {be_price:,.0f}/Nm³** ({be_mult:.2f}x)
    - LCOE M4 base **Rp {base_lcoe_m4:,.0f}** → harga jual harus > LCOE agar layak.
    - Rekomendasi: 
      1. Harga industri Rp 6.500-7.500 (preset optimistis)
      2. Carbon credit Rp 50/kg CO2e ≈ +Rp 800/Nm³
      3. Efisiensi OPEX -15% via shared manpower KUD
    """)
    st.markdown('</div>', unsafe_allow_html=True)
    df_feed=data.get('feedstock', pd.DataFrame())
    if not df_feed.empty:
        st.dataframe(df_feed, use_container_width=True, hide_index=True)

# What-if scenario chart: NPV vs Harga
st.markdown("### 📈 What-If: NPV vs Harga Jual Bio-CNG")
prices=[]
npvs_m4=[]
npvs_konv=[]
for mult in np.linspace(0.5,3.0,26):
    npv_t,_ ,_ = recalc_npv(data.get('cf_m4_dict',{}), discount_rate, capex_mult, mult, feedstock_mult, opex_mult)
    npv_t2,_ ,_ = recalc_npv(data.get('cf_konv_dict',{}), discount_rate, capex_mult, mult, feedstock_mult, opex_mult)
    prices.append(mult*4500)
    npvs_m4.append(npv_t/1e9 if npv_t else 0)
    npvs_konv.append(npv_t2/1e9 if npv_t2 else 0)
fig_w=go.Figure()
fig_w.add_trace(go.Scatter(x=prices, y=npvs_m4, mode='lines+markers', name='M4 NPV', line=dict(color='#16a34a', width=3)))
fig_w.add_trace(go.Scatter(x=prices, y=npvs_konv, mode='lines', name='Konv NPV', line=dict(color='#ef4444', width=2, dash='dot')))
fig_w.add_hline(y=0, line_dash="dash", line_color="black")
fig_w.add_vline(x=4500*harga_cng_mult, line_dash="dot", line_color="blue", annotation_text=f"Skenario saat ini Rp {4500*harga_cng_mult:,.0f}")
if be_price: fig_w.add_vline(x=be_price, line_dash="dash", line_color="green", annotation_text=f"Break-even Rp {be_price:,.0f}")
fig_w.update_layout(template="plotly_white", xaxis_title="Harga Jual Bio-CNG (Rp/Nm³)", yaxis_title="NPV (Rp Miliar)", height=380, hovermode="x unified")
st.plotly_chart(fig_w, use_container_width=True)

# ---------- PDF EXPORT ----------
st.markdown("---")
st.markdown("### 📄 Export Laporan Tesis")

def generate_pdf_report():
    if not HAS_REPORTLAB:
        return None
    buffer=io.BytesIO()
    doc=SimpleDocTemplate(buffer, pagesize=A4, rightMargin=20*mm, leftMargin=20*mm, topMargin=20*mm, bottomMargin=20*mm)
    styles=getSampleStyleSheet()
    story=[]
    story.append(Paragraph(f"Laporan Tekno-Ekonomi Bio-CNG KPBS Pangalengan - {datetime.now().strftime('%d %B %Y')}", styles['Title']))
    story.append(Spacer(1,12))
    story.append(Paragraph(f"Skenario: {preset} | Discount Rate {discount_rate*100:.1f}% | Harga Jual Rp {4500*harga_cng_mult:,.0f}/Nm³", styles['Normal']))
    story.append(Spacer(1,12))
    data_table=[
        ["Indikator", "M4", "Konvensional", "Keterangan"],
        ["NPV Simulasi", f"Rp {npv_m4:,.0f}", f"Rp {npv_konv:,.0f}", f"Break-even Rp {be_price:,.0f}/Nm³"],
        ["NPV Base Excel", f"Rp {base_npv_m4:,.0f}" if base_npv_m4 else "N/A", f"Rp {base_npv_konv:,.0f}" if base_npv_konv else "N/A", "Dari sheet Kelayakan"],
        ["LCOE Base", f"Rp {base_lcoe_m4:,.0f}/Nm³" if base_lcoe_m4 else "N/A", f"Rp {base_lcoe_konv:,.0f}/Nm³" if base_lcoe_konv else "N/A", "Biaya levelized"],
        ["Payback", f"{calc_payback(cum_m4):.1f} th" if calc_payback(cum_m4) else ">15 th", f"{calc_payback(cum_konv):.1f} th" if calc_payback(cum_konv) else ">15 th", "Simple payback"],
        ["CAPEX Efektif", f"Rp {8222000000*capex_mult:,.0f}", f"Rp {8592000000*capex_mult:,.0f}", f"Mult {capex_mult}x"],
        ["Asumsi", f"Feedstock {feedstock_mult}x, OPEX {opex_mult}x", "", ""],
    ]
    t=Table(data_table, colWidths=[90, 110, 110, 130])
    t.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), colors.HexColor("#16a34a")),
        ('TEXTCOLOR', (0,0), (-1,0), colors.white),
        ('ALIGN', (0,0), (-1,-1), 'LEFT'),
        ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
        ('FONTSIZE', (0,0), (-1,-1), 9),
        ('GRID', (0,0), (-1,-1), 0.5, colors.grey),
        ('BACKGROUND', (0,1), (-1,-1), colors.HexColor("#f0fdf4")),
    ]))
    story.append(t)
    story.append(Spacer(1,12))
    story.append(Paragraph("Catatan: Nilai bersifat ilustratif (warna biru di Excel). Wajib kalibrasi dengan data primer lapangan KPBS Pangalengan, uji TS/VS/BMP, dan penawaran vendor EPC.", styles['Italic']))
    story.append(Spacer(1,12))
    story.append(Paragraph("Rekomendasi Optimasi: 1) Harga jual premium industri Rp 6.500-7.500/Nm³, 2) Carbon credit & insentif EBT, 3) Reduksi OPEX via shared operator KUD, 4) Skema M4 lebih unggul Rp 353 Juta vs Konvensional pada base case.", styles['Normal']))
    doc.build(story)
    buffer.seek(0)
    return buffer

col_pdf1, col_pdf2 = st.columns(2)
with col_pdf1:
    if HAS_REPORTLAB:
        pdf_buffer=generate_pdf_report()
        if pdf_buffer:
            st.download_button(label="📥 Download Laporan PDF (Tesis)", data=pdf_buffer, file_name=f"Laporan_BioCNG_KPBS_{preset.replace(' ','_')}_{datetime.now().strftime('%Y%m%d')}.pdf", mime="application/pdf")
    else:
        st.warning("Install reportlab untuk PDF: pip install reportlab")

with col_pdf2:
    # Export simulasi cashflow CSV
    df_export=pd.DataFrame({"Tahun":years, "M4_Net_Simulasi":cf_m4_adj, "M4_Kumulatif":cum_m4, "Konv_Net_Simulasi":cf_konv_adj, "Konv_Kumulatif":cum_konv})
    csv=df_export.to_csv(index=False).encode('utf-8')
    st.download_button("📊 Download Cashflow Simulasi CSV", csv, "cashflow_simulasi_bioCNG.csv", "text/csv")

st.caption("Dashboard v2 | Streamlit + Plotly | Break-even Finder + PDF Export | © 2026 KPBS Pangalengan - Suryaman Aan")
